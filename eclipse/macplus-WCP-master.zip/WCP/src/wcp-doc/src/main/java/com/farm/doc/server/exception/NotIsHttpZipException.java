package com.farm.doc.server.exception;

public class NotIsHttpZipException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5439455131912587745L;

}
