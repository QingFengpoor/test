package com.farm.parameter.exception;

public class KeyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6064027268304270441L;

}
