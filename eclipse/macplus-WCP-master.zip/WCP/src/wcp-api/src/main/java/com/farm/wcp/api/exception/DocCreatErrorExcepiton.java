package com.farm.wcp.api.exception;

/** 文档无法创建异常
 * @author wangdong
 *
 */
public class DocCreatErrorExcepiton extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DocCreatErrorExcepiton(Exception e) {
		super(e);
	}

}
