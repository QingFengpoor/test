package com.farm.core.para.impl;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.farm.core.ParameterService;

public class ParaTestImpl implements ParameterService {

	@Override
	public Map<String, String> getDictionary(String key) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<Entry<String, String>> getDictionaryList(String index) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getParameter(String key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getParameter(String key, String userId) {
		// TODO Auto-generated method stub
		return null;
	}


}
