package com.farm.web.test;

import com.farm.core.auth.domain.LoginUser;

public class FarmTest {
	public LoginUser user =null;
}
