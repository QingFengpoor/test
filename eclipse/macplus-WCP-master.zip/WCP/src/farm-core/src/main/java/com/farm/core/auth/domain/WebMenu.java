package com.farm.core.auth.domain;

public interface WebMenu {
	public String getParams();

	public String getIcon();

	public String getUrl();

	public String getName();

	public String getParentid();

	public String getId();
}
