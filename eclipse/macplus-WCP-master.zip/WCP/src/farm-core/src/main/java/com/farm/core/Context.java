package com.farm.core;

public class Context {
	public static String MK;
	public static String FK;
	public static boolean FLAG;
}
