package com.farm.core.auth.exception;

public class LoginUserNoExistException extends Exception {
	public LoginUserNoExistException(String message) {
		super(message);
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 6482296763929242398L;

}
