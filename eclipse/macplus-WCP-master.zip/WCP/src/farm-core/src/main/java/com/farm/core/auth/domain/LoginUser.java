package com.farm.core.auth.domain;

public interface LoginUser {

	public String getId();

	public String getName();

	public String getLoginname();

}
