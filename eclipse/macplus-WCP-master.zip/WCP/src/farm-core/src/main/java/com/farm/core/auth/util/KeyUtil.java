package com.farm.core.auth.util;
public class KeyUtil {
	@SuppressWarnings("unused")
	private static String errorkey = "ERROR";
	@SuppressWarnings("unused")
	private static String CODE_C = "SADFSEV";
	public static String getFkey(String mkey) {
		return "NONE";
	}
	public static String getMKey() {
		return "NONE";
	}
}
