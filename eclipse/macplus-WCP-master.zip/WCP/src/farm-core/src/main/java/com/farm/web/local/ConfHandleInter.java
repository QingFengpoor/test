package com.farm.web.local;

import java.io.File;

public interface ConfHandleInter {
	public void execute(Object para,File file);
}
