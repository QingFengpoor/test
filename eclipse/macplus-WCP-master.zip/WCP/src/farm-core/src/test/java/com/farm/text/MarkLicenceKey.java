package com.farm.text;

import com.farm.core.auth.util.KeyUtil;
public class MarkLicenceKey {
	public static void main(String[] args) {
		System.out.println(KeyUtil.getMKey());
		//System.out.println(KeyUtil.getFkey("8C8-60723AA5"));
		System.out.println(KeyUtil.getFkey("C4B-8AF11814"));
	}
}
